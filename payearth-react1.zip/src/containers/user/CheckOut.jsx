import React, { Component } from "react";
import Header from "../../components/user/common/Header";
import PageTitle from "../../components/user/common/PageTitle";
import Footer from "../../components/common/Footer";
import { connect } from "react-redux";
import axios from "axios";
//import { toast } from 'react-toastify';
import store from '../../store/index';
import { toast } from 'react-toastify';
//coinbase inport
import CoinbaseCommerceButton from "react-coinbase-commerce";
import 'react-coinbase-commerce/dist/coinbase-commerce-button.css';

class CheckOut extends Component {
    constructor(props) {
        super(props);
        this.authInfo = store.getState().auth.authInfo;
        this.state = {
            chargeData: '',
            checkoutData: '',
            apiData: [],
            statusData: [],
            data: [],
            reqBody: {
                count: {
                    page: 1,
                    skip: 0,
                    limit: 2,
                    data: ''
                },
                sorting: {
                    sort_type: "date",
                    sort_val: "desc"
                }
            },
            autherStatus: '',
            user_id: '',
            paymentType: '',
        };
    }

    componentDidMount() {
        this.getNewCouponCode();
        this.CoinBase();
    }


    //get new Coupon code
    getNewCouponCode = () => {
        let reqBody = this.state.reqBody
        axios.post('user/coupons/new', reqBody, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json;charset=UTF-8',
                'Authorization': `Bearer ${this.authInfo.token}`,
            }
        }).then((response) => {
            this.setState({ data: response.data.data.coupons })
            console.log(response.data.data.coupons)
        }).catch(error => {
            console.log(error)
        });
    }   //get new Coupon code

    render() {
        const cart = this.props.cart
        const userInfo = JSON.parse(localStorage.getItem('userInfo'));
        const fullname = userInfo.name;
        const [first, last] = fullname.split(' ');


        // submit Function
        this.onSubmit = () => {
            let disCode = document.getElementById('myCoupon').value
            console.log(disCode)
            //this.setState({ couponCode: disCode })
            let reqBody = {}
            let user = this.authInfo.id
            reqBody = {
                count: {
                    page: 1,
                    skip: 0,
                    limit: 2,
                    data: '',
                },
                sorting: {
                    sort_type: "date",
                    sort_val: "desc"
                },
                data: disCode,
                user_id: user
            }

            if (disCode === '') {
                toast.error('Coupon code is blank')
            } else {
                //check isActive is true
                axios.post('user/coupons/check', reqBody, {
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json;charset=UTF-8',
                        'Authorization': `Bearer ${this.authInfo.token}`,
                    }
                }).then((response) => {
                    this.setState({ apiData: response.data.data.coupons })

                }).catch(error => {
                    console.log(error)
                    toast.error('This code is already used or code is not match')
                });//check isActive is true
            }
        }    //onSubmit() 


        const getTotal = () => {

            const newDesApi = this.state.apiData;
            var newDiscount = ''
            newDesApi.forEach(val => {
                newDiscount = val.discount_per
            })
            let totalQuantity = 0
            let disCode = newDiscount
            let totalPrice = 0
            let GST = 18
            let totalAmmount = 0
            let discount = 0
            let tax = 0
            cart.forEach(items => {
                totalQuantity += items.quantity
                totalPrice += items.price * items.quantity
                tax = totalPrice * GST / 100
                //totalAmmount = totalPrice + tax
                if (disCode === undefined) {
                    discount = 0
                    totalAmmount = totalPrice + tax
                } else {
                    discount = totalPrice * disCode / 100
                    totalAmmount = totalPrice + tax - discount
                }
            })
            return { totalPrice, totalQuantity, totalAmmount, discount, tax }
        }//getTotal();


        this.CoinBase = () => {

            var proName = ''
            var proId = ''
            var proImg = ''

            cart.forEach((item) => {
                proName = item.name;
                proId = item.id;
                proImg = item.image
            })

            //Create Checkout

            const getCheckout = () => {
                let data = JSON.stringify({
                    "name": proName,
                    "logo": proImg,
                    "description": proId,
                    "pricing_type": "fixed_price",
                    "local_price": {
                        "amount": '0.1',
                        "currency": "USD"
                    },
                    "requested_info": [
                        "name",
                        "email"
                    ],
                });

                let config = {
                    method: 'post',
                    url: 'https://api.commerce.coinbase.com/checkouts',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CC-Version': '2018-03-22',
                        'X-CC-Api-Key': '001f0600-823b-4801-ad79-57cd6c12814b'
                    },
                    data: data
                };

                try {
                    axios(config)
                        .then((response) => {
                            console.log(response);
                            this.setState({ checkoutData: response.data.data })
                        })
                } catch (err) {
                    console.log('Error', err)
                }

            }
            getCheckout();// end Checkout

            //create charges
            const GetCharge = () => {
                let data = JSON.stringify({
                    "logo": proImg,
                    "name": proName,
                    "description": proId,
                    "pricing_type": "fixed_price",
                    "local_price": {
                        "amount": '0.1',
                        "currency": "USD"
                    },
                    "metadata": {
                        "customer_id": "12345",
                        "customer_name": "payearth"
                    },
                    "cancel_url": "https://localhost:3001/checkout",
                    "redirect_url": "https://localhost:3001/"
                });

                let config = {
                    method: 'post',
                    url: 'https://api.commerce.coinbase.com/charges',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CC-Version': '2018-03-22',
                        'X-CC-Api-Key': '001f0600-823b-4801-ad79-57cd6c12814b'
                    },
                    data: data
                };

                try {
                    axios(config)
                        .then((response) => {
                            console.log(response.data);
                            this.setState({ chargeData: response.data.data })
                        })
                } catch (err) {
                    console.log('Error', err)
                }


            }//end Charges
            GetCharge()

            const createEnvoice = () => {
                let config = {
                    method: 'get',
                    url: 'https://api.commerce.coinbase.com/invoices',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CC-Version': '2018-03-22',
                        'X-CC-Api-Key': '001f0600-823b-4801-ad79-57cd6c12814b'
                    }
                };

                axios(config)
                    .then((response) => {
                        console.log(response.data);
                    })
                    .catch((error) => {
                        console.log(error);
                    });
            }//end envoice  
            createEnvoice();
        }        //end coinbase


        const coinbaseObj = {
            onLoad: () => { console.log('loading') },
            onChargeSuccess: (MessageData) => { console.log(MessageData) },
            onChargeFailure: (MessageData) => { console.log(MessageData) },
            onPaymentDetected: (MessageData) => { console.log(MessageData) },
            onModalClosed: () => { console.log('onModalClosed') },
            customMetadata: () => { console.log('customMetadata') },
        }
        const onValueChange = (event) => {
            this.setState({
                paymentType: event.target.value
            });
        }

        return (
            <React.Fragment>
                <Header />
                <PageTitle title="CheckOut" />
                <section className="inr_wrap checkout_wrap">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="cart my_cart">
                                    <div className="cart_wrap">
                                        <div className="items_incart">
                                            <span>have a coupons <a href="">Click here to have</a></span>
                                        </div>
                                        <div className="cart_wrap">
                                            <div className="checkout_cart_wrap">
                                                <p>IF YOU HAVE A COUPON CODE,PLEASE APPLY IT BELOW </p>
                                                <div className="input-group d-flex">
                                                    <input type="text" className="form-control" placeholder="Enter your coupons code" aria-label="Example text with button addon"
                                                        id="myCoupon"
                                                    />
                                                    <button className="btn custom_btn btn_yellow" type="button" onClick={this.onSubmit} > Apply coupns code</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-md-8">
                                            <div style={{ "padding": "0px 0px 0px 25px" }} className="checkout_form_section">
                                                <div className="items_incart">
                                                    <h4>BILLING DETAILS</h4>
                                                </div>
                                                <div className="checkout-form">
                                                    <form action="">
                                                        <div className="checkout_form_wrapper">
                                                            <div className="input-group ">
                                                                <div className="form_field">
                                                                    <label htmlFor="">First Name <span>*</span></label>
                                                                    <input type="text" className="form-control" value={first} />
                                                                </div>
                                                            </div>
                                                            <div className="input-group ">
                                                                <div className="form_field">
                                                                    <label htmlFor="">Last Name<span>*</span></label>
                                                                    <input type="text" className="form-control" value={last} />
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="checkout_form_wrapper">
                                                            <div className="input-group ">
                                                                <div className="form_field" style={{ width: '76%' }}>
                                                                    <label htmlFor="">Company Name(optional)</label>
                                                                    <input type="text" className="form-control" />
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="checkout_form_wrapper">
                                                            <div className="input-group ">
                                                                <div className="form_field" style={{ width: '76%' }}>
                                                                    <label htmlFor="">Country/Region<span>*</span></label>
                                                                    <div className="dropdown">
                                                                        <button className="dropdown-toggle form-control text-left" type="button" data-toggle="dropdown">United kingdom
                                                                            <span className="caret"></span>
                                                                        </button>
                                                                        <ul className="dropdown-menu">
                                                                            <li><a href="#">US</a></li>
                                                                            <li><a href="#">India</a></li>
                                                                            <li><a href="#">India</a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="checkout_form_wrapper">
                                                            <div className="input-group ">
                                                                <div className="form_field" style={{ width: '76%' }}>
                                                                    <label htmlFor="">Street Address <span>*</span></label>
                                                                    <input className="form-control" type="text" placeholder="House number and street number" style={{ "marginBottom": "15px" }} /><br />
                                                                    <input className="form-control" type="text" placeholder="House number" />
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="checkout_form_wrapper">
                                                            <div className="input-group ">
                                                                <div className="form_field" style={{ width: '76%' }}>
                                                                    <label htmlFor="">Town/City<span>*</span></label>
                                                                    <input type="text" className="form-control" />
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="checkout_form_wrapper">
                                                            <div className="input-group ">
                                                                <div className="form_field" style={{ width: '76%' }}>
                                                                    <label htmlFor="">Country(Optional)</label>
                                                                    <input type="text" className="form-control" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="checkout_form_wrapper">
                                                            <div className="input-group ">
                                                                <div className="form_field" style={{ width: '76%' }}>
                                                                    <label htmlFor="">Postcode<span>*</span></label>
                                                                    <input type="number" className="form-control" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="checkout_form_wrapper">
                                                            <div className="input-group ">
                                                                <div className="form_field" style={{ width: '76%' }}>
                                                                    <label htmlFor="">Phone<span>*</span></label>
                                                                    <input type="tel" className="form-control" name="" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="checkout_form_wrapper">
                                                            <div className="input-group ">
                                                                <div className="form_field" style={{ width: '76%' }}>
                                                                    <label htmlFor="">Email<span>*</span></label>
                                                                    <input type="email" className="form-control" value={userInfo.email} />
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="checkout_form_wrapper">
                                                            <div className="input-group ">
                                                                <div className="form_field" style={{ width: '76%' }}>
                                                                    <input type="radio" id="first-radio" name="" value="" />
                                                                    <label htmlFor="first-radio">Selet your label</label>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="checkout_form_wrapper">
                                                            <div className="input-group ">
                                                                <div className="form_field" style={{ width: '76%' }}>
                                                                    <label htmlFor="">Note<span>*</span></label>
                                                                    <textarea name="" className="form-control" placeholder="Note about your oder" id="" cols="30" rows="10"></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-md-4">
                                            <div className="payment_method_section">
                                                <div className="payment_list">
                                                    <ul>
                                                        <li>Price({getTotal().totalQuantity}) : {getTotal().totalPrice}$ </li>
                                                        <li>Tax(18%) : {getTotal().tax}$ </li>
                                                        <li>Discount : {getTotal().discount}$ </li>
                                                        <li>Delivery Charges: 0$ </li>
                                                    </ul>
                                                </div>
                                                <div className="subtotal_wrapper">
                                                    <ul>
                                                        <li>Subtotal  : {getTotal().totalAmmount}$</li>
                                                    </ul>
                                                </div>

                                                <div className="payment_method_wrapper">
                                                    <b>Select any option for Payment </b>
                                                    <ul>
                                                        <li className="payment_list">
                                                            <div className="">
                                                                <input
                                                                    type="radio"
                                                                    id=""
                                                                    name="payment"
                                                                    value="wise"
                                                                    checked={this.state.paymentType === "wise"}
                                                                    onChange={onValueChange}
                                                                />
                                                                <span>Wise</span>
                                                            </div>

                                                            {/* <div className="dropdown">
                                                                <button className=" dropdown-toggle" type="button" data-toggle="dropdown">Select Payment Method
                                                                    <span className="caret"></span></button>
                                                                <ul className="dropdown-menu">
                                                                    <li><a href="#">Visa</a></li>
                                                                    <li><a href="#">Bank to bank</a></li>
                                                                    <li><a href="#">Paypal</a></li>
                                                                </ul>
                                                            </div> */}

                                                        </li>
                                                    </ul>
                                                    <ul>
                                                        <li>
                                                            <div className="">
                                                                <input
                                                                    type="radio"
                                                                    id=""
                                                                    name="payment"
                                                                    value="cripto"
                                                                    checked={this.state.paymentType === "cripto"}
                                                                    onChange={onValueChange}
                                                                />
                                                                <span>
                                                                    {console.log(this.state.paymentType)}
                                                                    Cripto
                                                                </span>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div className="">
                                                    {/* <a className="btn custom_btn btn_yellow" >Place Order</a> */}
                                                    {console.log(this.state.chargeData.id)}
                                                    {console.log(this.state.chargeData.code)}
                                                    {this.state.paymentType=== 'wise' ? <button>Wise Transfer</button> : ''}
                                                    {this.state.paymentType=== 'cripto' ? <div>
                                                        <CoinbaseCommerceButton
                                                            styled={true}
                                                            checkoutId={this.state.checkoutData.id}
                                                            chargeId={this.state.chargeData.code}
                                                            onLoad={coinbaseObj.onLoad}
                                                            onChargeSuccess={coinbaseObj.onChargeSuccess}
                                                            onChargeFailure={coinbaseObj.onChargeFailure}
                                                            onPaymentDetected={coinbaseObj.onPaymentDetected}
                                                            // onModalClosed={coinbaseObj.onModalClosed}
                                                            disableCaching={false}
                                                        />
                                                    </div> : ''}
                                                    
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>
                <Footer />
            </React.Fragment>
        )
    }
}
//export default CheckOut;
const mapStateToProps = state => {
    return {
        cart: state.cart.cart
    }
}

export default connect(mapStateToProps)(CheckOut);